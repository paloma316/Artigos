/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package artigos1;

/**
 *
 * @author Paloma
 */
public class ArtigosClass {
    
 //variables
    
String designacao;
double preco;
int quantidade;


//construtor vázio
public ArtigosClass(){
    
}
//construtor para inicializar as variaáveis

    public ArtigosClass(String designacao, double preco, int quantidade) {
        this.designacao = designacao;
        this.preco = preco;
        this.quantidade = quantidade;
    }
    
    //get e set

    public String getDesignacao() {
        return designacao;
    }

    public void setDesignacao(String designacao) {
        this.designacao = designacao;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
    
    //toString

    @Override
    public String toString() {
        return "ArtigosClass{" + "designacao=" + designacao + ", preco=" + preco + ", quantidade=" + quantidade + '}';
    }
    


    
}
