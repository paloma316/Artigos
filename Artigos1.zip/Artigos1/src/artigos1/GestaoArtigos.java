/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package artigos1;

import java.awt.Cursor;
import java.util.ArrayList;

/**
 *
 * @author Paloma
 */
public class GestaoArtigos {
    
    //variavel arrayList
    //constructor this productList=new ArrayList<artigos>
    //métodos:
      //-guardar artigos,returnar artigos,comprar artigos
    public ArrayList<ArtigosClass> artigosArray;
    
    //get e set

    public ArrayList<ArtigosClass> getArtigosArray() {
        fillArtigos();
        return artigosArray;
    }

    public void setArtigosArray(ArrayList<ArtigosClass> artigosArray) {
        this.artigosArray = artigosArray;
    }
    
    
    
    public GestaoArtigos(){
        artigosArray=new ArrayList<>();
       
    }
    //   public ArtigosClass(String designacao, double preco, int quantidade)
    public void fillArtigos(){
      //  String output="";
        ArtigosClass a1=new ArtigosClass("apple",2.2,3);
        ArtigosClass a2=new ArtigosClass("strawberies",2.3,3);
        ArtigosClass a3=new ArtigosClass("banana",4.5,3);
        ArtigosClass a4= new ArtigosClass("jaca",3.4,56);
        ArtigosClass a5=new ArtigosClass("cherry",5.6,4);
        
        addArtigos(a1);
        addArtigos(a2);
        addArtigos(a3);
        addArtigos(a4);
        addArtigos(a5);
        
        /*
        
          String output = "";
        for (Artigo a : tArtigos){
            output += a.toString();
        }
        return output;
        */
        
     
    //    return output;
        
    }
    public void addArtigos(ArtigosClass artigo){
        artigosArray.add(artigo);
      
    }
    
  
    
    
    public double getTotalPrice(){
        double total=0.0;
        
        
        
        return total;
    }
    

    
}
